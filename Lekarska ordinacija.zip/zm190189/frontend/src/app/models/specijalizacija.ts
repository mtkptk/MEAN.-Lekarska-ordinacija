export class Specijalizacija{
    _id: string;
    naziv: string;
}