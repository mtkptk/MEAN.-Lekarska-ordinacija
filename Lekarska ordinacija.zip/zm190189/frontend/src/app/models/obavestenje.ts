export class Obavestenje{
    _id: string;
    type: string;
    opis: string;
}