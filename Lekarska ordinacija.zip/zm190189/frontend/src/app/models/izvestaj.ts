export class Izvestaj{
    _id: string;
    kada: number;
    lekar_ime: string;
    lekar_spec: string;
    razlog: string;
    dijagnoza: string;
    terapija: string;
    kontrola: number;
    pacijent_id: string;
    lekar_id: string;
    termin_id: string;
}