export class Pregled{
    _id: string;
    spec: string;
    naziv: string;
    zakaziv: boolean;
    cena: number;
    trajanje: number;
    request: boolean;
}