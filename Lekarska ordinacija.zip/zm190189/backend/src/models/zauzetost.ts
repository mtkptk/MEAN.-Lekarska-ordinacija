/*import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Zauzetost = new Schema({
    start: {type: Number},
    duration: {type: Number},
    odmor: {type: Boolean},
    lekar_id: {type: String}
})

export default mongoose.model('Zauzetost', Zauzetost, 'Zauzetost');*/